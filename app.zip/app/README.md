# Steps

1. `sudo mongod`
2. `mongo`
3. `npm install`
4. `npm install -g nodemon`
5. `nodemon server.js`

For MongoDB GUI: [Robomongo](https://robomongo.org/download)

